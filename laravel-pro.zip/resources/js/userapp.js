import './bootstrap';

// Bootstrap CSS
import 'bootstrap/dist/css/bootstrap.min.css';
import './user/front.js';

// Bootstrap JS
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
 // chart js
import Chart from 'chart.js/auto';

import "@fortawesome/fontawesome-free/css/all.min.css";
