<footer>
  <div class="container-fluid footeer">
    <div class="col-12 foot-back">
      <p>@powered by Rafi</p>
    </div>
  </div>
</footer>