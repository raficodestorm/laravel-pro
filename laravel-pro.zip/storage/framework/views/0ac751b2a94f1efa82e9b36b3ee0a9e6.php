<?php $__env->startSection('content'); ?>

<div class="container-fluid main-area">
    <div class="index-card shadow">
        <div class="card-header p-2 mb-3 text-white fw-bold" style="background-color: #ff0000">Edit Location</div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('locations.update', $location->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label class="form-label fw-semibold">District</label>
                    <input type="text" name="district" class="form-control" value="<?php echo e($location->district); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Division</label>
                    <input type="text" name="division" class="form-control" value="<?php echo e($location->division); ?>">
                </div>

                <button type="submit" class="btn btn-success px-4">Update</button>
                <a href="<?php echo e(route('locations.index')); ?>" class="btn btn-secondary px-4">Back</a>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Rafi-1288480\laravel-pro\resources\views\pages\admin\location\edit.blade.php ENDPATH**/ ?>