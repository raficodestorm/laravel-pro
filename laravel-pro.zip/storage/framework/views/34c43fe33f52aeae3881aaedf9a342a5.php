<?php $__env->startSection('content'); ?>
<div class="container-fluid main-area">
  <div class="index-card">
    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h2 class="text-center">All Buses</h2>
      <a href="<?php echo e(route('buses.create')); ?>" class="btn btn-info">Add New Bus</a>
    </div>

    <table class="table table-bordered table-hover" id="table-same">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Coach</th>
          <th>License</th>
          <th>Company</th>
          <th>Bus type</th>
          <th>Seat layout</th>
          <th>Route</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <th scope="row"><?php echo e($loop->iteration); ?></th>
          <td><?php echo e($bus->name); ?></td>
          <td><?php echo e($bus->coach_no); ?></td>
          <td><?php echo e($bus->license); ?></td>
          <td><?php echo e($bus->company); ?></td>
          <td><?php echo e($bus->bus_type); ?></td>
          <td><?php echo e($bus->seat_layout); ?></td>
          <td><?php echo e($bus->route); ?></td>
          <td>
            <a href="<?php echo e(route('buses.show', $bus)); ?>" class="btn btn-sm btn-info">View</a>
            <a href="<?php echo e(route('buses.edit', $bus)); ?>" class="btn btn-sm btn-warning">Edit</a>
            <form action="<?php echo e(route('buses.destroy', $bus)); ?>" method="POST" class="d-inline"
              onsubmit="return confirm('Are you sure you want to delete this bus?')">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button class="btn btn-sm btn-danger">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="7" class="text-center text-muted">No records found.</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>

    <div class="d-flex justify-content-center">

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Programing\PHP\laravel-pro\resources\views/pages/admin/bus/index.blade.php ENDPATH**/ ?>