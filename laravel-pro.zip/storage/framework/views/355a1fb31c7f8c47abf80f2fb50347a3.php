<?php $__env->startSection('content'); ?>
<div class="container mt-5 mb-5" style="min-height: 100vh;">
  <h3 class="fw-bold text-center mb-4" style="color:#780116;">
    Available Buses on <?php echo e(date('d M, Y', strtotime($date))); ?>

  </h3>

  <?php if($schedules->isEmpty()): ?>
  <div class="text-center mt-5">
    <h5 class="text-muted">😔 No buses found for your search.</h5>
    <a href="<?php echo e(route('bus.search.form')); ?>" class="btn btn-danger mt-3">Search Again</a>
  </div>
  <?php else: ?>
  <div class="row justify-content-center">
    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-10 mb-4">
      <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body d-flex flex-column flex-md-row align-items-md-center justify-content-between">
          <div>
            <h5 class="fw-bold mb-1" style="color:#780116;"><?php echo e($schedule->bus_type); ?> - Coach <?php echo e($schedule->coach_no); ?>

            </h5>
            <p class="mb-1 text-muted">
              <?php echo e($schedule->start_location); ?> → <?php echo e($schedule->end_location); ?>

            </p>
            <p class="small mb-0 text-secondary">
              Distance: <?php echo e($schedule->distance ?? 'N/A'); ?> | Duration: <?php echo e($schedule->duration ?? 'N/A'); ?>

            </p>
          </div>

          <div class="text-center my-3 my-md-0">
            <h6 class="fw-bold mb-1">🕒 <?php echo e(date('h:i A', strtotime($schedule->set_time))); ?></h6>
            <p class="small text-secondary mb-0">Departure Time</p>
          </div>

          <div class="text-center">
            <h5 class="fw-bold mb-1 text-danger">৳ <?php echo e(number_format($schedule->price, 2)); ?></h5>
            <button class="btn btn-outline-danger btn-sm rounded-3 mt-1">View Seats</button>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Rafi-1288480\laravel-pro\resources\views\pages\user\search-schedule-result.blade.php ENDPATH**/ ?>