<?php $__env->startSection('content'); ?>

<div class="container-fluid main-area">
    <div class="index-card shadow">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>All Locations</h3>
            <a href="<?php echo e(route('locations.create')); ?>" class="btn btn-info">+ Add Location</a>
        </div>

        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered align-middle" id="table-same">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>District</th>
                    <th>Division</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="text-center">
                    <td><?php echo e($location->id); ?></td>
                    <td><?php echo e($location->district); ?></td>
                    <td><?php echo e($location->division ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('locations.show', $location->id)); ?>" class="btn btn-info btn-sm">View</a>
                        <a href="<?php echo e(route('locations.edit', $location->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('locations.destroy', $location->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Are you sure?')"
                                class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-muted">No locations found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php echo e($locations->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Programing\PHP\laravel-pro\resources\views/pages/admin/location/index.blade.php ENDPATH**/ ?>