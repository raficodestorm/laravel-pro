<footer>
  <div class="container-fluid footeer">
    <div class="col-12 foot-back">
      <p>@powered by Rafi</p>
    </div>
  </div>
</footer><?php /**PATH D:\Rafi-1288480\laravel-pro\resources\views\components\adminfooter.blade.php ENDPATH**/ ?>