<?php $__env->startSection('content'); ?>

<div class="container-fluid main-area">
    <div class="index-card shadow">
        <div class="card-header p-2 mb-3 text-white fw-bold" style="background-color: #ff0000">Route Details</div>
        <div class="card-body">
            <p><strong>ID:</strong> <?php echo e($route->id); ?></p>
            <p><strong>Route code:</strong> <?php echo e($route->route_code); ?></p>
            <p><strong>Start location:</strong> <?php echo e($route->start_location); ?></p>
            <p><strong>End location:</strong> <?php echo e($route->End_location); ?></p>
            <p><strong>Distance:</strong> <?php echo e($route->distance); ?></p>
            <p><strong>duration:</strong> <?php echo e($route->duration); ?></p>
            <p><strong>Created at:</strong> <?php echo e($route->created_at); ?></p>

            <a href="<?php echo e(route('routes.index')); ?>" class="btn btn-secondary mt-3 px-4">Back</a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Rafi-1288480\laravel-pro\resources\views\pages\admin\route\show.blade.php ENDPATH**/ ?>