

<?php $__env->startSection('content'); ?>
<div class="container payment-page my-5">
  <?php if(session('success')): ?>
  <div class="alert alert-success">
    <?php echo e(session('success')); ?>

  </div>
  <?php endif; ?>

  <div class="row">
    
    <div class="col-md-5">
      <div class="card shadow-lg p-4 rounded-4 mb-4">
        <h4 class="mb-3">🚌 Booking Summary</h4>
        <p>
          <strong>Passenger:</strong> <?php echo e($bookingData->name); ?> <br>
          <strong>Mobile:</strong> <?php echo e($bookingData->mobile); ?> <br>
          <strong>Boarding:</strong> <?php echo e($bookingData->boarding); ?> <br>
          <strong>Dropping:</strong> <?php echo e($bookingData->dropping); ?> <br>
        </p>

        <p>
          <strong>Bus Type:</strong> <?php echo e($bookingData->Bus_type); ?> <br>
          <strong>Coach No:</strong> <?php echo e($bookingData->coach_no); ?> <br>
          <strong>Route:</strong> <?php echo e($bookingData->route); ?> <br>
          <strong>Departure:</strong> <?php echo e($bookingData->departure); ?>

        </p>

        <p>
          <strong>Seats:</strong>
          <?php if(!empty($bookingData->selected_seats)): ?>
          <?php echo e($bookingData->selected_seats); ?>

          <?php else: ?>
          No seats selected
          <?php endif; ?>
        </p>

        <?php
        // Extract total amount (remove currency symbol if present)
        $totalAmount = preg_replace('/[^\d.]/', '', $bookingData['total'] ?? 0);
        ?>

        <div class="fare-summary mt-3">
          <h5>Total Fare:</h5>
          <h3 class="text-success">৳ <?php echo e(number_format($bookingData->total, 2)); ?></h3>
        </div>
      </div>
    </div>

    
    <div class="col-md-7">
      <div class="card shadow-lg p-4 rounded-4">
        <h4 class="mb-3">💳 Payment Details</h4>

        <form method="POST" action="<?php echo e(route('payment.process')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="bookingData" value='<?php echo json_encode($bookingData, 15, 512) ?>'>

          
          <div class="mb-3">
            <label class="form-label">Select Payment Method:</label>
            <select class="form-select" id="paymentMethod" name="paymentMethod" required
              onchange="togglePaymentFields(this.value)">
              <option value="">-- Choose Method --</option>
              <option value="card">Credit/Debit Card</option>
              <option value="wallet">Mobile Wallet (bKash, Nagad, Rocket)</option>
              <option value="netbanking">Net Banking</option>
              <option value="cod">Cash at Counter</option>
            </select>
          </div>

          
          <div id="cardFields" style="display: none;">
            <div class="mb-3">
              <label class="form-label">Card Number</label>
              <input type="text" name="cardNumber" class="form-control" placeholder="1234 5678 9012 3456">
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Expiry Date</label>
                <input type="text" name="expiry" class="form-control" placeholder="MM/YY">
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">CVV</label>
                <input type="password" name="cvv" class="form-control" placeholder="123">
              </div>
            </div>
          </div>

          
          <div id="walletFields" style="display: none;">
            <div class="mb-3">
              <label class="form-label">Wallet Number</label>
              <input type="text" name="walletNumber" class="form-control" placeholder="01XXXXXXXXX">
            </div>
          </div>

          
          <div id="codNotice" style="display: none;">
            <div class="alert alert-info">
              You have chosen <strong>Cash at Counter</strong>. Please pay at the bus counter before departure.
            </div>
          </div>

          
          <button type="submit" class="btn btn-success w-100 rounded-3 py-2 mt-3">
            Confirm & Pay ৳<?php echo e(number_format($totalAmount, 2)); ?>

          </button>
        </form>
      </div>
    </div>
  </div>
</div>


<script>
  function togglePaymentFields(method) {
    document.getElementById('cardFields').style.display = (method === 'card') ? 'block' : 'none';
    document.getElementById('walletFields').style.display = (method === 'wallet') ? 'block' : 'none';
    document.getElementById('codNotice').style.display = (method === 'cod') ? 'block' : 'none';
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Programing\PHP\laravel-pro\resources\views/pages/user/payment.blade.php ENDPATH**/ ?>