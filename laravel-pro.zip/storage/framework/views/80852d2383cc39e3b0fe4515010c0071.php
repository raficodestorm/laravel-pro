<?php $__env->startSection('content'); ?>

<div class="container-fluid main-area">
    <div class="index-card shadow">
        <div class="card-header text-white fw-bold p-2 mb-3" style="background-color: #ff0000">Add New Route</div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('routes.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Route code</label>
                    <input type="text" name="route_code" class="form-control" placeholder="Enter route code" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Start location</label>
                    <input type="text" name="start_location" class="form-control" list="start" placeholder="Start from">
                    <datalist id="start"></datalist>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">End location</label>
                    <input type="text" name="end_location" class="form-control" list="end" placeholder="End to">
                    <datalist id="end"></datalist>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Distance</label>
                    <input type="text" name="distance" class="form-control" placeholder="distance">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Duration</label>
                    <input type="text" name="duration" class="form-control" placeholder="duration">
                </div>
                <button type="submit" class="btn btn-success px-4">Save</button>
                <a href="<?php echo e(route('routes.index')); ?>" class="btn btn-secondary px-4">Back</a>
            </form>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Rafi-1288480\laravel-pro\resources\views\pages\admin\route\create.blade.php ENDPATH**/ ?>