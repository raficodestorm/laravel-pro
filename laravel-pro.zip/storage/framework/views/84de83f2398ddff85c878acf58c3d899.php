<?php $__env->startSection('content'); ?>

<div class="container-fluid main-area">
    <div class="index-card shadow">
        <div class="card-header p-2 mb-3 text-white fw-bold" style="background-color: #ff0000">Location Details</div>
        <div class="card-body">
            <p><strong>ID:</strong> <?php echo e($location->id); ?></p>
            <p><strong>District:</strong> <?php echo e($location->district); ?></p>
            <p><strong>Division:</strong> <?php echo e($location->division ?? '-'); ?></p>
            <p><strong>Created at:</strong> first time</p>

            <a href="<?php echo e(route('locations.index')); ?>" class="btn btn-secondary mt-3 px-4">Back</a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Rafi-1288480\laravel-pro\resources\views\pages\admin\location\show.blade.php ENDPATH**/ ?>