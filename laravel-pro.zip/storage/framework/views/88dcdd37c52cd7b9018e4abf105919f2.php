<?php $__env->startSection('content'); ?>
<div class="container-fluid main-area">
  <div class="index-card shadow">
    <div class="card-header text-white fw-bold p-2 mb-3 text-center py-3 rounded-top-4"
      style="background-color: #ff0000">
      <h4 class="mb-0">🚌 Add New Bus</h4>
    </div>

    <div class="card-body p-4">
      
      <?php if(session('success')): ?>
      <div class="alert alert-success">
        <?php echo e(session('success')); ?>

      </div>
      <?php endif; ?>

      
      <form action="<?php echo e(route('buses.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="name" class="form-label">Bus Name</label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Enter bus name" required
              value="<?php echo e(old('name')); ?>">
          </div>

          <div class="col-md-6">
            <label for="coach_no" class="form-label">Coach Number</label>
            <input type="number" name="coach_no" id="coach_no" class="form-control" placeholder="e.g. 101" required
              value="<?php echo e(old('coach_no')); ?>">
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="license" class="form-label">License Number</label>
            <input type="text" name="license" id="license" class="form-control" placeholder="e.g. DHA-12345" required
              value="<?php echo e(old('license')); ?>">
          </div>

          <div class="col-md-6">
            <label for="company" class="form-label">Company Name</label>
            <input type="text" name="company" id="company" class="form-control" placeholder="e.g. Green Line" required
              value="<?php echo e(old('company')); ?>">
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label for="bus_type" class="form-label">Bus type</label>
            <input type="text" name="bus_type" id="bus_type" class="form-control" placeholder="AC/Non-AC/Sleeper"
              required value="<?php echo e(old('bus_type')); ?>">
          </div>

          <div class="col-md-6">
            <label for="seat_layout" class="form-label">Seat layout</label>
            <input type="text" name="seat_layout" id="seat_layout" class="form-control" placeholder="26/30/36/40"
              required value="<?php echo e(old('seat_layout')); ?>">
          </div>
        </div>

        <div class="mb-4">
          <label for="route" class="form-label">Route</label>
          <input type="text" name="route" id="route" class="form-control" placeholder="e.g. Dhaka – Chittagong" required
            value="<?php echo e(old('route')); ?>">
        </div>

        <div class="text-end">
          <button type="submit" class="btn btn-success px-4">Save Bus</button>
          <a href="<?php echo e(route('buses.index')); ?>" class="btn btn-secondary px-4">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Rafi-1288480\laravel-pro\resources\views\pages\admin\bus\create.blade.php ENDPATH**/ ?>