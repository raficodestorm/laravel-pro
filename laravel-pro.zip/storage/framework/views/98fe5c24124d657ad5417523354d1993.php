<?php $__env->startSection('content'); ?>

<div class="container-fluid main-area">
    <div class="index-card shadow">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>All Schedules</h3>
            <a href="<?php echo e(route('schedules.create')); ?>" class="btn btn-info">+ Add Shedule</a>
        </div>

        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered align-middle" id="table-same">
            <thead class="table-dark text-center">
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Route</th>
                    <th>Start location</th>
                    <th>End location</th>
                    <th>Distance</th>
                    <th>Duration</th>
                    <th>Price</th>
                    <th>Bus type</th>
                    <th>Coach no</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="text-center">
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($schedule->set_date); ?></td>
                    <td><?php echo e($schedule->set_time); ?></td>
                    <td><?php echo e($schedule->route_code); ?></td>
                    <td><?php echo e($schedule->start_location); ?></td>
                    <td><?php echo e($schedule->end_location); ?></td>
                    <td><?php echo e($schedule->distance); ?></td>
                    <td><?php echo e($schedule->duration); ?></td>
                    <td><?php echo e($schedule->price); ?></td>
                    <td><?php echo e($schedule->bus_type); ?></td>
                    <td><?php echo e($schedule->coach_no); ?></td>

                    <td>
                        <a href="<?php echo e(route('schedules.show', $schedule->id)); ?>" class="btn btn-info btn-sm">View</a>
                        <a href="<?php echo e(route('schedules.edit', $schedule->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('schedules.destroy', $schedule->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Are you sure?')"
                                class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-muted">No locations found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php echo e($schedules->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Rafi-1288480\laravel-pro\resources\views\pages\admin\schedule\index.blade.php ENDPATH**/ ?>