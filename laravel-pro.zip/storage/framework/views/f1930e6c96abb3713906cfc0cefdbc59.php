<?php $__env->startSection('content'); ?>
<div class="container-fluid main-area ">
  <div class="justify-center">
    <div class="index-card shadow">
      <h2>Bus Detail</h2>
      <p><strong>Store ID:</strong> <?php echo e($bus->id); ?></p>
      <p><strong>Bus Name:</strong> <?php echo e($bus->name); ?></p>
      <p><strong>Coach No:</strong> <?php echo e($bus->coach_no); ?></p>
      <p><strong>License:</strong> <?php echo e($bus->license); ?></p>
      <p><strong>Company:</strong> <?php echo e($bus->company); ?></p>
      <p><strong>Company:</strong> <?php echo e($bus->bus_type); ?></p>
      <p><strong>Company:</strong> <?php echo e($bus->seat_layout); ?></p>
      <p><strong>Route:</strong> <?php echo e($bus->route); ?></p>
      <p><strong>added at:</strong> <?php echo e($bus->created_at); ?></p>

      <a href="<?php echo e(route('buses.index')); ?>" class="btn btn-secondary">Back</a>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Rafi-1288480\laravel-pro\resources\views\pages\admin\bus\show.blade.php ENDPATH**/ ?>